import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import random
from collections import deque
import sys, os
sys.path.append(os.path.dirname(os.path.abspath(__file__)) + '/../..')
from simulator.video_player import Player

# 定义Q网络
class QNetwork(nn.Module):
    def __init__(self, state_size, action_size):
        super(QNetwork, self).__init__()
        self.fc1 = nn.Linear(state_size, 64)
        self.fc2 = nn.Linear(64, 64)
        self.fc3 = nn.Linear(64, action_size)
    
    def forward(self, state):
        x = torch.relu(self.fc1(state))
        x = torch.relu(self.fc2(x))
        return self.fc3(x)

# 定义DQN智能体
class DQNAgent:
    def __init__(self, state_size, action_size):
        self.state_size = state_size
        self.action_size = action_size
        self.memory = deque(maxlen=2000)
        self.gamma = 0.95
        self.epsilon = 1.0
        self.epsilon_decay = 0.995
        self.epsilon_min = 0.01
        self.learning_rate = 0.001
        self.model = QNetwork(state_size, action_size)
        self.optimizer = optim.Adam(self.model.parameters(), lr=self.learning_rate)
        self.criterion = nn.MSELoss()
    
    def remember(self, state, action, reward, next_state, done):
        self.memory.append((state, action, reward, next_state, done))
    
    def act(self, state):
        if np.random.rand() <= self.epsilon:
            return random.randrange(self.action_size)
        state = torch.FloatTensor(state).unsqueeze(0)
        act_values = self.model(state)
        return np.argmax(act_values.detach().numpy()[0])
    
    def replay(self, batch_size):
        minibatch = random.sample(self.memory, batch_size)
        for state, action, reward, next_state, done in minibatch:
            target = reward
            if not done:
                next_state = torch.FloatTensor(next_state).unsqueeze(0)
                target = reward + self.gamma * torch.max(self.model(next_state)[0]).item()
            state = torch.FloatTensor(state).unsqueeze(0)
            target_f = self.model(state)
            target_f[0][action] = target
            self.optimizer.zero_grad()
            loss = self.criterion(target_f, self.model(state))
            loss.backward()
            self.optimizer.step()
        if self.epsilon > self.epsilon_min:
            self.epsilon *= self.epsilon_decay

    def load(self, path):
        self.model.load_state_dict(torch.load(path))
    
    def save(self, path):
        torch.save(self.model.state_dict(), path)

class Algorithm:
    def __init__(self):
        self.state_size = 6  # 根据状态表示调整
        self.action_size = 3  # [download_video_id, bit_rate, sleep_time]
        self.agent = DQNAgent(self.state_size, self.action_size)
        self.buffer_size = 0

    # 初始化
    def Initialize(self):
        self.buffer_size = 0

    # 定义算法
    def run(self, delay, rebuf, video_size, end_of_video, play_video_id, Players, first_step=False):
        # 构建当前状态
        state = np.array([delay, rebuf, video_size, end_of_video, play_video_id, self.buffer_size])

        # 智能体选择动作
        action = self.agent.act(state)

        # 解析动作
        download_video_id = action // 9
        bit_rate = (action % 9) // 3
        sleep_time = (action % 3) * 500.0

        # 更新buffer_size（根据实际情况可能需要调整）
        self.buffer_size = max(0, self.buffer_size - delay + sleep_time / 1000.0 - rebuf)

        # 返回选择的动作
        return download_video_id, bit_rate, sleep_time
    
def run_dqn_agent(env, episodes=1000, batch_size=32):
    state_size = 6  # 根据你的状态定义调整
    action_size = 3  # 根据你的动作定义调整
    agent = DQNAgent(state_size, action_size)

    for e in range(episodes):
        state = env.reset()  # 根据你的环境初始化状态
        for time in range(500):  # 最大步数，根据需要调整
            action = agent.act(state)
            next_state, reward, done, _ = env.step(action)  # 根据环境获取新的状态、奖励和结束信号
            agent.remember(state, action, reward, next_state, done)
            state = next_state
            if done:
                print(f"Episode: {e}/{episodes}, score: {time}, e: {agent.epsilon:.2}")
                break
            if len(agent.memory) > batch_size:
                agent.replay(batch_size)

    agent.save("dqn_model.pth")  # 保存模型

# 主函数启动训练
if __name__ == "__main__":
    from simulator.controller import Player  # 确保这是正确的导入
    env = Player(video_num=10)  # 设置正确的 video_num 参数值
    run_dqn_agent(env, episodes=1000, batch_size=32)
